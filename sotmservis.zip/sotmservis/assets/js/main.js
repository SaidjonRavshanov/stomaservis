// Kelajakda kerak bo'ladigan umumiy funksiyalar uchun
document.addEventListener('DOMContentLoaded', function() {
    console.log("Dashboard yuklandi!");
});